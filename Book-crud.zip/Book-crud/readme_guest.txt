buka di browser chrome dengan link localhost/Book-crud
Button add Book untuk menambah buku baru,
button edit utk update buku dan button delete utk menghapus data buku